# Production observability evidence

- Timestamp (UTC): 2026-08-17T10:01:14Z
- Prometheus production API metric samples: 4
- Loki production entries in the last 30 minutes: 6
- Tempo production traces in the last 30 minutes: 4

The JSON files retain labels, timestamps and trace identifiers, but deliberately
exclude log messages and all authentication material.
