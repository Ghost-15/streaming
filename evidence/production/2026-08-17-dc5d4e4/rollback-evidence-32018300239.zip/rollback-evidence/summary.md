# Production deployment evidence

- Timestamp (UTC): 2026-08-17T10:04:04Z
- HTTPS health URL: https://streampulse-api-1jxg.onrender.com/health
- Render service: srv-d9t5o2ajobas73elb61g
- Render deploy: dep-da1dovrl550s73ff01n0
- Render status: live
- Runtime image manifest digest: sha256:db3af481c8084ab2eda39c8fdb3cc36c18401796f91a4587019eddb2bdb4cdd9
- Business smoke URL: https://streampulse-api-1jxg.onrender.com/api/v1/streams
- Business smoke result: valid JSON array
- HTTP redirect status: 301
- HTTP redirect location: https://streampulse-api-1jxg.onrender.com/health
- Health payload: `{"service":"streampulse-api","status":"ok"}`

The artifact also contains the sanitized Render deploy response, verbose curl
TLS negotiation, redirect headers, the leaf certificate details and chain.
