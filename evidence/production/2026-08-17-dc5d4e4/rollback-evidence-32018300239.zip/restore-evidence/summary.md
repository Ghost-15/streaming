# Production deployment evidence

- Timestamp (UTC): 2026-08-17T10:04:29Z
- HTTPS health URL: https://streampulse-api-1jxg.onrender.com/health
- Render service: srv-d9t5o2ajobas73elb61g
- Render deploy: dep-da1dp649v7es73b6eabg
- Render status: live
- Runtime image manifest digest: sha256:d741f210c44555a6ad6ebda4d91ffcfd732a79687e9f3963bb6e334601e90912
- Business smoke URL: https://streampulse-api-1jxg.onrender.com/api/v1/streams
- Business smoke result: valid JSON array
- HTTP redirect status: 301
- HTTP redirect location: https://streampulse-api-1jxg.onrender.com/health
- Health payload: `{"service":"streampulse-api","status":"ok"}`

The artifact also contains the sanitized Render deploy response, verbose curl
TLS negotiation, redirect headers, the leaf certificate details and chain.
